
public class CALCULO_INTERES_SIMPLE {

	public static void main(String[] args) {
		
		double tiempo = 12.36;
		int tasa = 7;
		double principal = 32.87;
		double interes = tiempo * tasa * principal;
		System.out.println(interes);

	}

}
