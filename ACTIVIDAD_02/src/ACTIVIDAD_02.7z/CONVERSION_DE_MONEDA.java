
public class CONVERSION_DE_MONEDA {

	public static void main(String[] args) {
		final double tasa = 0.85;
		double dolar = 68.45;
		double euro = tasa * dolar;
		System.out.println("la conversión a euros es" + euro + "€");
		

		
	}

}
