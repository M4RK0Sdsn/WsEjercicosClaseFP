
public class CONVERSION_FAHRENHEIT_CELSIUS {

	public static void main(String[] args) {
		
		int fahrenheit = 235;
		int celsius = (fahrenheit - 32) * 5 / 9;
		System.out.println(celsius);
		
		fahrenheit = 678;
		celsius = (fahrenheit - 32) * 5 / 9;
		System.out.println(celsius);

		
		

	}

}
