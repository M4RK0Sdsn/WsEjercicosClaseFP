
public class CALCULO_AREA_CIRCULO {

	public static void main(String[] args) {
		
		final double NUMERO_PI = 3.1416;
		int radio = 3 ;
		double area = (radio * radio)* NUMERO_PI;
		System.out.println("El area del circulo es de" + area + "cm");

	}

}
