
public class AREA_Y_PERIMETRO {

	public static void main(String[] args) {
		
		//ÁREA Y PERÍMETRO DE UN RECTANGULO
		
		int longitud = 5;
		int ancho = 10;
		int perimetro = 2 * ancho + longitud;
		System.out.println(perimetro);
		int area = ancho * longitud;
		System.out.println("El area 1 es de" + area + "cm");
		
		int longitud2 = 7;
		int ancho2 = 3;
		int perimetro2 = 2 * ancho2 * longitud2;
		System.out.println(perimetro2);
		int area2 = longitud2 * ancho2;
		System.out.println("El area 2 es de" + area2 + "cm");
		
		
		
		
		
		
		

	}

}
