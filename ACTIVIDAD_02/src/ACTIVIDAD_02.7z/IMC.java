
public class IMC {

	public static void main(String[] args) {
		
		double peso = 62;
		double altura = 1.75;
		double IMC = peso / (altura * altura);
		System.out.println( "Mi IMC es de" + IMC);

	}

}
